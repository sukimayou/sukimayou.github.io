# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:\creditcard\success.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Failure(object):
    def setupUi(self, Failure):
        Failure.setObjectName(_fromUtf8("Failure"))
        Failure.resize(360, 110)
        self.label = QtGui.QLabel(Failure)
        self.label.setGeometry(QtCore.QRect(10, 10, 341, 71))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.pushButton = QtGui.QPushButton(Failure)
        self.pushButton.setGeometry(QtCore.QRect(260, 80, 81, 21))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))

        self.retranslateUi(Failure)
        QtCore.QMetaObject.connectSlotsByName(Failure)

    def retranslateUi(self, Failure):
        Failure.setWindowTitle(_translate("Failure", "Totally Not Malware", None))
        self.label.setText(_translate("Failure", "Thank you so much, onii-chan~", None))
        self.pushButton.setText(_translate("Failure", "OK", None))